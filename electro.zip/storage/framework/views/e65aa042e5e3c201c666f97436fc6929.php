
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($key); ?>"
                    class="<?php echo e($key == 0 ? 'active' : ''); ?>" aria-current="<?php echo e($key == 0 ? 'true' : ''); ?>"
                    aria-label="Slide <?php echo e($key + 1); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="carousel-inner">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                    <img src="<?php echo e(asset('images/' . $banner->image)); ?>" class="d-block w-100" alt="<?php echo e($banner->title); ?>">
                    <div class="carousel-caption d-none d-md-block">
                        <h5><?php echo e($banner->title); ?></h5>
                        <p><?php echo e($banner->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Carousel cho sản phẩm giảm giá -->
    <div class="bg-danger">
        <div class="container">
            <h3 class="m-0 title py-3">SALE SẬP SÀN</h3>
            <div class="owl-carousel owl-theme">
                <?php $__currentLoopData = $discountedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="card bg-hove position-relative">
                            <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                                <div class="product-img">
                                    <img src="<?php echo e(asset('images/' . $product->image_url)); ?>" class="card-img-top"
                                        alt="<?php echo e($product->name); ?>">
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                    class="text-decoration-none text-dark-custom product-name">
                                    <?php echo e($product->name); ?>

                                    <?php if($product->discount_percentage): ?>
                                        <!-- Biểu tượng "Sale" -->
                                        <div
                                            class="position-absolute top-0 end-0 bg-danger text-white text-center p-2 rounded-start">
                                            <?php echo e($product->discount_percentage); ?>%
                                        </div>
                                    <?php endif; ?>
                                </a>
                                <div class="product-price-wrapper">
                                    <p class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                    <?php if($product->old_price): ?>
                                        <div class="price-sale">
                                            <del class="product-old-price"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                                ₫</del>
                                        </div>
                                    <?php else: ?>
                                        <div class="price-sale empty-sale"></div>
                                    <?php endif; ?>
                                </div>
                                <div
                                    class="product-btn d-flex flex-column flex-sm-row justify-content-center align-items-center">
                                    <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                        class="text-decoration-none mb-2 mb-sm-0">
                                        <button class="btn btn-danger me-md-1">
                                            <i class="fa fa-shopping-cart me-1"></i>
                                            <span class="small">Giỏ hàng</span>
                                        </button>
                                    </a>

                                    <a href="<?php echo e(route('favorites.add', $product->id)); ?>" class="text-decoration-none">
                                        <button class="btn btn-secondary">
                                            <i class="fas fa-heart me-1 ms-md-1"></i>
                                            <span class="small">Yêu thích</span>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Carousel cho sản phẩm hot -->
    <div class="container my-4">
        <h3 class="title mb-1 ">SẢN PHẨM HOT</h3>
        <div class="owl-carousel owl-theme">
            <?php $__currentLoopData = $hotProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="card">
                        <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                            <div class="product-img">
                                <img src="<?php echo e(asset('images/' . $product->image_url)); ?>" class="card-img-top"
                                    alt="<?php echo e($product->name); ?>">
                            </div>
                        </a>
                        <div class="card-body text-center">
                            <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                class="text-decoration-none text-dark-custom product-name">
                                <?php echo e($product->name); ?>

                            </a>
                            <div class="product-price-wrapper">
                                <p class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                <?php if($product->old_price): ?>
                                    <div class="price-sale">
                                        <del class="product-old-price"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                            ₫</del>
                                    </div>
                                <?php else: ?>
                                    <div class="price-sale empty-sale"></div>
                                <?php endif; ?>
                            </div>
                            <div
                                class="product-btn d-flex flex-column flex-sm-row justify-content-center align-items-center">
                                <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                    class="text-decoration-none mb-2 mb-sm-0">
                                    <button class="btn btn-danger">
                                        <i class="fa fa-shopping-cart me-1"></i>
                                        <span class="small">Giỏ hàng</span>
                                    </button>
                                </a>
                                <a href="<?php echo e(route('favorites.add', $product->id)); ?>" class="text-decoration-none">
                                    <button class="btn btn-secondary">
                                        <i class="fas fa-heart me-1"></i>
                                        <span class="small">Yêu thích</span>
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Sản phẩm theo loại -->
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container my-4">
            <h3 class="title mb-1"><?php echo e($category->category_name); ?></h3>
            <div class="owl-carousel owl-theme">
                <?php $__currentLoopData = $categoryProducts[$category->category_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="card">
                            <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                                <div class="product-img">
                                    <img src="<?php echo e(asset('images/' . $product->image_url)); ?>" class="card-img-top"
                                        alt="<?php echo e($product->name); ?>">
                                </div>
                            </a>
                            <div class="card-body text-center">
                                <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                    class="text-decoration-none text-dark-custom product-name">
                                    <?php echo e($product->name); ?>

                                </a>
                                <div class="product-price-wrapper">
                                    <p class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                    <?php if($product->old_price): ?>
                                        <div class="price-sale">
                                            <del class="product-old-price"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                                ₫</del>
                                        </div>
                                    <?php else: ?>
                                        <div class="price-sale empty-sale"></div>
                                    <?php endif; ?>
                                </div>
                                <div
                                    class="product-btn d-flex flex-column flex-sm-row justify-content-center align-items-center">
                                    <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                        class="text-decoration-none mb-2 mb-sm-0">
                                        <button class="btn btn-danger me-md-1">
                                            <i class="fa fa-shopping-cart me-1"></i>
                                            <span class="small">Giỏ hàng</span>
                                        </button>
                                    </a>

                                    <a href="<?php echo e(route('favorites.add', $product->id)); ?>" class="text-decoration-none">
                                        <button class="btn btn-secondary">
                                            <i class="fas fa-heart me-1 ms-md-1"></i>
                                            <span class="small">Yêu thích</span>
                                        </button>
                                    </a>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center my-3">
                <a href="<?php echo e(route('productsClient.productByCategory', ['slug' => $category->slug])); ?>"
                    class="btn btn-danger">Xem tất cả</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Carousel cho tất cả sản phẩm -->
    <div class="container my-4">
        <h3 class="title mb-1">Tất cả sản phẩm</h3>
        <div class="owl-carousel owl-theme">
            <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="card">
                        <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                            <div class="product-img">
                                <img src="<?php echo e(asset('images/' . $product->image_url)); ?>" class="card-img-top"
                                    alt="<?php echo e($product->name); ?>">
                            </div>
                        </a>
                        <div class="card-body text-center">
                            <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                class="text-decoration-none text-dark-custom product-name">
                                <?php echo e($product->name); ?>

                            </a>
                            <div class="product-price-wrapper">
                                <p class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                <?php if($product->old_price): ?>
                                    <div class="price-sale">
                                        <del class="product-old-price"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                            ₫</del>
                                    </div>
                                <?php else: ?>
                                    <div class="price-sale empty-sale"></div>
                                <?php endif; ?>
                            </div>
                            <div
                                class="product-btn d-flex flex-column flex-sm-row justify-content-center align-items-center">
                                <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                    class="text-decoration-none mb-2 mb-sm-0">
                                    <button class="btn btn-danger me-md-1">
                                        <i class="fa fa-shopping-cart me-1"></i>
                                        <span class="small">Giỏ hàng</span>
                                    </button>
                                </a>

                                <a href="<?php echo e(route('favorites.add', $product->id)); ?>" class="text-decoration-none">
                                    <button class="btn btn-secondary">
                                        <i class="fas fa-heart me-1 ms-md-1"></i>
                                        <span class="small">Yêu thích</span>
                                    </button>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/client/home.blade.php ENDPATH**/ ?>