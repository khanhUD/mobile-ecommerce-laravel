<!-- Thêm Banner Modal -->
<div class="modal fade" id="addbannerModal" tabindex="-1" aria-labelledby="addbannerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addbannerModalLabel">Thêm Banner</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="bannerAddForm" action="<?php echo e(asset('admin/banners/them-xu-ly')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="title" class="form-label">Tiêu đề</label>
                        <input type="text" class="form-control" id="title" name="title">
                        <span id="titleError" class="text-danger"></span>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Mô tả</label>
                        <textarea class="form-control" id="description" name="description"></textarea>
                        <span id="descriptionError" class="text-danger"></span>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Ảnh</label>
                        <input type="file" class="form-control" id="image" name="image">
                        <span id="imageError" class="text-danger"></span>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Trạng thái</label><br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                            <label class="form-check-label" for="active">Hiển thị</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                            <label class="form-check-label" for="inactive">Ẩn</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="clearErrors()" data-bs-dismiss="modal">Đóng</button>
                        <button type="button" onclick="validateForm()" class="btn btn-primary">Thêm</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<!-- Modal -->

<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/pages/admin/banners/add.blade.php ENDPATH**/ ?>