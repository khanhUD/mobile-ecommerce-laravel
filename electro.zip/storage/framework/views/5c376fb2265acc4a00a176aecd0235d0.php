
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 ">
                <h1 class="p-0"><?php echo e($post->title); ?></h1>
                <div class=" gx-4 mt-2 mb-3">
                    <div class="author d-flex align-items-center">
                        <div class="avatar rounded-circle shadow bg-gradient-dark">
                            <img src="<?php echo e($post->author->image ? asset('images/' . $post->author->image) : asset('images/no_images.jpg')); ?>"
                                alt="logo" class="img-fluid rounded-circle" style="max-width: 50px; height: auto;">
                        </div>
                        <div class="name ps-2">
                            <div class="d-flex flex-column">
                                <h5 class="mb-1"><?php echo e($post->author->name); ?></h5>
                                <p class="mb-0 font-weight-normal text-sm">
                                    <?php echo e($post->created_at->format('d/m/Y')); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="mx-2">
                <div class="row container text-dark">
                    <p><?php echo $post->content; ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/client/blogDetail.blade.php ENDPATH**/ ?>