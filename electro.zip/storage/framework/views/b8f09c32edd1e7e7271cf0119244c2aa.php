<div>
<div style="text-align: center">
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
</div>
</div>
<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/livewire/counter.blade.php ENDPATH**/ ?>