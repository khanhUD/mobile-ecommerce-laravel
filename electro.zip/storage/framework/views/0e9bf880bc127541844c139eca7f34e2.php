<?php echo e($slot); ?>

<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>