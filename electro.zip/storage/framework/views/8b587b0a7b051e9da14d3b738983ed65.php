<!DOCTYPE html>
<html lang="vi">

<?php echo $__env->make('components.client.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <!-- header  -->
    <?php echo $__env->make('components.client.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header  -->

    <!-- NAVIGATION -->
    <?php echo $__env->make('components.client.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /NAVIGATION -->
    <!-- contetnt  -->


    <!-- contetnt  -->
    <!-- banner -->
    <!-- end banner -->

    <!-- product  -->
    <?php echo $__env->yieldContent('content'); ?>
    <!--end  product  -->

    <!-- end contetnt  -->

    <!-- FOOTER -->
    <?php echo $__env->make('components.client.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.client.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- /FOOTER -->
    <?php echo $__env->make('components.client.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/layouts/client/main.blade.php ENDPATH**/ ?>