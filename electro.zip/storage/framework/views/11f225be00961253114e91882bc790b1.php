

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container ">
    <div class="row">
        <div class="page-header min-height-300 border-radius-xl mt-4" style="background-image: url('https://images.unsplash.com/photo-1531512073830-ba890ca4eba2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=1920&amp;q=80');">
            <span class="mask  bg-gradient-primary  opacity-6"></span>
        </div>
        <div class="card card-body mx-3 mx-md-4 mt-n6">
            <div class="row gx-4 mb-2">
                <div class="col-auto">
                    <div class="avatar avatar-xl position-relative">
                        <img src="<?php echo e(asset('uploads/team-2.jpg')); ?>" alt="profile_image" class="w-100 border-radius-lg shadow-sm">
                    </div>
                </div>
                <div class="col-auto my-auto">
                    <div class="h-100">
                        <h5 class="mb-1">
                            Nguyễn Quốc Khanh
                        </h5>
                        <p class="mb-0 font-weight-normal text-sm">
                            Người dùng
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-xl-4">
                    <div class="card card-plain h-100">
                        <div class="card-header pb-0 p-3">
                            <div class="row">
                                <div class="col-md-7 d-flex align-items-center">
                                    <h6 class="mb-0">Thông tin cá nhân</h6>
                                </div>
                                <div class="col-md-5 text-end">
                                    <button type="button" class="btn btn-primary text-capitalize mb-0" data-bs-toggle="modal" data-bs-target="#editUsersModal">
                                        Cập nhật
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-3">
                            <p class="text-sm">
                                Xin chào, tôi là Khanh, Quyết định: Nếu bạn không thể quyết định thì câu trả lời là không.
                                Nếu hai con đường khó khăn như nhau,
                                hãy chọn con đường đau đớn hơn trong thời gian ngắn (né tránh nỗi đau là tạo ra ảo tưởng về sự bình đẳng).
                                Chưa mở rộng
                            </p>
                            <hr class="horizontal gray-light my-4">
                            <ul class="list-group">
                                <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark">Họ và tên:</strong> &nbsp;Chưa mở rộng</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Số điện thoại:</strong> &nbsp; Chưa mở rộng</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Email:</strong> &nbsp; Khanh@gmail.com</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Địa chỉ:</strong> &nbsp; Chưa mở rộng </li>
                                <li class="list-group-item border-0 ps-0 pb-0">
                                    <strong class="text-dark text-sm">Mạng xã hội:</strong> &nbsp;
                                    <a class="btn btn-facebook btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                                        <i class="fab fa-facebook fa-lg" aria-hidden="true">Chưa mở rộng</i>
                                    </a>
                                    <a class="btn btn-twitter btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                                        <i class="fab fa-twitter fa-lg" aria-hidden="true">Chưa mở rộng</i>
                                    </a>
                                    <a class="btn btn-instagram btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                                        <i class="fab fa-instagram fa-lg" aria-hidden="true">Chưa mở rộng</i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-xl-8 ">
                    <div class="p-3">
                        <h6 class="mb-1">Dự án (Chưa mở rộng)</h6>
                        <p class="text-sm">Kiến trúc sư thiết kế nhà ở</p>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-md-6 mb-xl-0 mb-4">
                            <div class="card card-blog card-plain">
                                <div class="card-header p-0 mt-n4 mx-3">
                                    <a class="d-block shadow-xl border-radius-xl">
                                        <img src="<?php echo e(asset('uploads/home-decor-1.jpg')); ?>" alt="Ảnh mờ bóng" class="img-fluid shadow border-radius-xl">
                                    </a>
                                </div>
                                <div class="card-body p-3">
                                    <p class="mb-0 text-sm">Dự án #2</p>
                                    <a href="javascript:;">
                                        <h5>
                                            Hiện đại
                                        </h5>
                                    </a>
                                    <p class="mb-4 text-sm">
                                        Khi Uber đang giải quyết một lượng lớn sự rối loạn trong quản lý nội bộ.
                                    </p>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <button type="button" class="btn btn-outline-primary btn-sm mb-0">Xem dự án</button>
                                        <div class="avatar-group mt-2">
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Elena Morison" data-bs-original-title="Elena Morison">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-1.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Ryan Milly" data-bs-original-title="Ryan Milly">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-2.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Nick Daniel" data-bs-original-title="Nick Daniel">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-3.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Peterson" data-bs-original-title="Peterson">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-4.jpg')); ?>">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6 mb-xl-0 mb-4">
                            <div class="card card-blog card-plain">
                                <div class="card-header p-0 mt-n4 mx-3">
                                    <a class="d-block shadow-xl border-radius-xl">
                                        <img src="<?php echo e(asset('uploads/home-decor-2.jpg')); ?>" alt="Ảnh mờ bóng" class="img-fluid shadow border-radius-lg">
                                    </a>
                                </div>
                                <div class="card-body p-3">
                                    <p class="mb-0 text-sm">Dự án #1</p>
                                    <a href="javascript:;">
                                        <h5>
                                            Bắc Âu
                                        </h5>
                                    </a>
                                    <p class="mb-4 text-sm">
                                        Âm nhạc là điều mà mỗi người có ý kiến cụ thể của riêng mình.
                                    </p>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <button type="button" class="btn btn-outline-primary btn-sm mb-0">Xem dự án</button>
                                        <div class="avatar-group mt-2">
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Nick Daniel" data-bs-original-title="Nick Daniel">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-3.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Peterson" data-bs-original-title="Peterson">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-4.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Elena Morison" data-bs-original-title="Elena Morison">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-1.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Ryan Milly" data-bs-original-title="Ryan Milly">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-2.jpg')); ?>">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6 mb-xl-0 mb-4">
                            <div class="card card-blog card-plain">
                                <div class="card-header p-0 mt-n4 mx-3">
                                    <a class="d-block shadow-xl border-radius-xl">
                                        <img src="<?php echo e(asset('uploads/home-decor-3.jpg')); ?>" alt="Ảnh mờ bóng" class="img-fluid shadow border-radius-xl">
                                    </a>
                                </div>
                                <div class="card-body p-3">
                                    <p class="mb-0 text-sm">Dự án #3</p>
                                    <a href="javascript:;">
                                        <h5>
                                            Tối giản
                                        </h5>
                                    </a>
                                    <p class="mb-4 text-sm">
                                        Mỗi người có khẩu vị khác nhau, và nhiều loại âm nhạc khác nhau.
                                    </p>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <button type="button" class="btn btn-outline-primary btn-sm mb-0">Xem dự án</button>
                                        <div class="avatar-group mt-2">
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Peterson" data-bs-original-title="Peterson">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-4.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Nick Daniel" data-bs-original-title="Nick Daniel">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-3.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Ryan Milly" data-bs-original-title="Ryan Milly">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-2.jpg')); ?>">
                                            </a>
                                            <a href="javascript:;" class="avatar avatar-xs rounded-circle" data-bs-toggle="tooltip" data-bs-placement="bottom" aria-label="Elena Morison" data-bs-original-title="Elena Morison">
                                                <img alt="Hình ảnh" src="<?php echo e(asset('uploads/team-1.jpg')); ?>">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modal edit -->
                    <div class="modal fade modal-lg" id="editUsersModal" tabindex="-1" aria-labelledby="editModalLabel1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel1">Sửa thông tin tài khoản</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="mb-3 ">
                                                    <label for="name" class="form-label">Tên</label>
                                                    <input type="text" class="form-control" id="name" name="name">
                                                </div>
                                                <div class="mb-3 ">
                                                    <label for="email" class="form-label">Email</label>
                                                    <input type="text" class="form-control" id="email" name="email">
                                                </div>
                                                <div class="mb-3 ">
                                                    <label for="usertype" class="form-label">Vai trò</label>
                                                    <input type="text" class="form-control" id="usertype" name="usertype">
                                                </div>
                                                <div class="mb-3 ">
                                                    <label for="image" class="form-label">Hình</label>
                                                    <input type="file" class="form-control" id="image" name="image">
                                                </div>
                                                <div class="mb-3 ">
                                                    <label for="status" class="form-label">Trạng Thái</label><br>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                                                        <label class="form-check-label" for="active">Mở</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                                                        <label class="form-check-label" for="inactive">Khóa</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <img src="<?php echo e(asset('uploads/team-2.jpg')); ?> " class="w-100 border-radius-lg" alt="user1">
                                            </div>
                                        </div>


                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                    <button type="button" class="btn btn-primary">Lưu</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modal -->
                </div>
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/admin/users/detail.blade.php ENDPATH**/ ?>