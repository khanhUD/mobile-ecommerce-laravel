<nav class="navbar navbar-main navbar-expand-lg px-0  shadow-none border-radius-xl" id="navbarBlur"
      data-scroll="true">
      <div class="container-fluid  ">
        <nav aria-label="breadcrumb">
          <h2 class="font-weight-bolder mb-0">index</h2>

        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4 " id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
            <div class="input-group input-group-outline">
              <label class="form-label">Tìm kiếm...</label>
              <input type="text" class="form-control">
            </div>

          </div>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="/dang-xuat" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>

                <span class="d-sm-inline d-none me-2">Đăng xuất</span>

              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/admin/nav.blade.php ENDPATH**/ ?>