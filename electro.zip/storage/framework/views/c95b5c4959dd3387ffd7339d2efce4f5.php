

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
  <div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 ">
          <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
            <h5 class="text-white text-capitalize ps-3">Danh sách banners</h5>
            <button type="button" class="btn btn-primary text-capitalize me-4" data-bs-toggle="modal" data-bs-target="#addbannerModal">
              Thêm mới
            </button>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tiêu đề</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mô tả</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Ảnh</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Trạng thái</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <h6 class="px-3 mb-0 text-sm"><?php echo e($banner->title); ?></h6>
                  </td>
                  <td>
                    <p class="text-xs font-weight-bold mb-0"><?php echo e($banner->description); ?></p>
                  </td>
                  <td>
                    <div data-bs-toggle="modal" data-bs-target="#imageBannerModal">
                      <img src="<?php echo e(asset('uploads/' . $banner->image)); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                    </div>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <span class="badge badge-sm <?php echo e($banner->status == 1 ? 'bg-gradient-success' : 'bg-gradient-danger'); ?>">
                      <?php echo e($banner->status == 1 ? 'Hiển thị' : 'Ẩn'); ?>

                    </span>

                  </td>

                  <td class="align-middle text-center">
                    <button type="button" class="btn btn-warning text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editModal1">
                      Edit
                    </button>
                    <button type="button" class="btn btn-secondary text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editModal1">
                      Xóa
                    </button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo $__env->make('pages.admin.banners.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('pages.admin.banners.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Modal ảnh Banner -->
  <div class="modal fade modal-lg" id="imageBannerModal" tabindex="-1" aria-labelledby="imageBannerLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <img src="<?php echo e(asset('uploads/team-2.jpg')); ?>" alt="user1" class="w-100">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/admin/banners/list.blade.php ENDPATH**/ ?>