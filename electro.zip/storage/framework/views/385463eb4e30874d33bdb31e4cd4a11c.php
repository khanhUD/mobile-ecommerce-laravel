<div>
    hello
    <?php echo e($test); ?>

</div>
<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/livewire/test-banner.blade.php ENDPATH**/ ?>