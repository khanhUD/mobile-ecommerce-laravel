

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
  <div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 ">
          <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
            <h5 class="text-white text-capitalize ps-3">Danh sách bài viết</h5>
            <button type="button" class="btn btn-primary text-capitalize me-4" data-bs-toggle="modal" data-bs-target="#addPostsModal">
              Thêm mới
            </button>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tác giả</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 p-0">Tiêu đề</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Trạng thái</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Ngày thêm</th>
                  <th class="text-secondary opacity-7"></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="d-flex px-3 py-1">
                      <div>
                        <img src="<?php echo e(asset('uploads/team-2.jpg')); ?> " class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                      </div>
                      <div class="d-flex flex-column justify-content-center">
                        <h6 class="mb-0 text-sm">Khanh</h6>
                        <p class="text-xs text-secondary mb-0">10.000.000 vnđ</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <a href="<?php echo e(asset('admin/bai-viet/chi-tiet')); ?>" class="text-xs font-weight-bold mb-0">110.000.000 vnđ0</a>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <span class="badge badge-sm bg-gradient-success">Hiển thị</span>
                  </td>
                  <td class="align-middle text-center">
                    <span class="text-secondary text-xs font-weight-bold">23/04/18</span>
                  </td>
                  <td class="align-middle">
                    <button type="button" class="btn btn-primary text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editPostsModal">
                      Edit
                    </button>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal add -->
  <div class="modal fade modal-lg" id="addPostsModal" tabindex="-1" aria-labelledby="addPostsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addPostsModalLabel">Thêm mới bài viết</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="">
            <div class="row">
              <div class="mb-3 col-6">
                <label for="user_id" class="form-label">Tác giả</label>
                <select class="form-select" id="user_id" name="user_id">
                  <option value="1">Tác giả 1</option>
                  <option value="2">Tác giả 2</option>
                  <!-- Thêm các tùy chọn khác nếu cần thiết -->
                </select>
              </div>
              <div class="mb-3 col-6">
                <label for="post_category_id" class="form-label">Loại bài viết</label>
                <select class="form-select" id="post_category_id" name="post_category_id">
                  <option value="1">Loại 1</option>
                  <option value="2">Loại 2</option>
                  <!-- Thêm các tùy chọn khác nếu cần thiết -->
                </select>
              </div>
              <div class="mb-3 col-6">
                <label for="name" class="form-label">Tên bài viết</label>
                <input type="text" class="form-control" id="name" name="name">
              </div>
              <div class="mb-3 col-6">
                <label for="status" class="form-label">Trạng Thái</label><br>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                  <label class="form-check-label" for="active">Hiển Thị</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                  <label class="form-check-label" for="inactive">Ẩn</label>
                </div>
              </div>
              <div class="mb-3">
                <label for="image" class="form-label">Ảnh</label>
                <input type="file" class="form-control" id="image" name="image">
              </div>
              <div class="mb-3">
                <div for="content" class="form-label">Nội dung bài viết</div>
                <div id="editor"></div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
          <button type="button" class="btn btn-primary">Thêm</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <!-- Modal edit -->
  <div class="modal fade modal-lg" id="editPostsModal" tabindex="-1" aria-labelledby="editPostsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editPostsModalLabel">Sửa bài viết</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="">
            <div class="row">
              <div class="mb-3 col-6">
                <label for="user_id" class="form-label">Tác giả</label>
                <select class="form-select" id="user_id" name="user_id">
                  <option value="1">Tác giả 1</option>
                  <option value="2">Tác giả 2</option>
                  <!-- Thêm các tùy chọn khác nếu cần thiết -->
                </select>
              </div>
              <div class="mb-3 col-6">
                <label for="post_category_id" class="form-label">Loại bài viết</label>
                <select class="form-select" id="post_category_id" name="post_category_id">
                  <option value="1">Loại 1</option>
                  <option value="2">Loại 2</option>
                  <!-- Thêm các tùy chọn khác nếu cần thiết -->
                </select>
              </div>


              <div class="mb-3 col-6">
                <label for="name" class="form-label">Tên bài viết</label>
                <input type="text" class="form-control" id="name" name="name">
              </div>
              <div class="mb-3 col-6">
                <label for="status" class="form-label">Trạng Thái</label><br>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                  <label class="form-check-label" for="active">Hiển Thị</label>
                </div>
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                  <label class="form-check-label" for="inactive">Ẩn</label>
                </div>
              </div>
              <div class="mb-3">
                <label for="image" class="form-label">Ảnh</label>
                <input type="file" class="form-control" id="image" name="image">
              </div>
              <div class="mb-3">
                <div for="content" class="form-label">Nội dung bài viết</div>
                <div id="editor2"></div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
          <button type="button" class="btn btn-primary">Lưu</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/admin/posts/list.blade.php ENDPATH**/ ?>