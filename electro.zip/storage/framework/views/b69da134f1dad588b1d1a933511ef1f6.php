

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3">
                    <div class="bg-gradient-dark shadow-dark border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
                        <h5 class="text-white text-capitalize ps-3 mb-0">Báo cáo khách hàng</h5>
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.reports.customers')); ?>" method="GET">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="start_date">Ngày bắt đầu</label>
                                    <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date', $startDate)); ?>">
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="end_date">Ngày kết thúc</label>
                                    <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date', $endDate)); ?>">
                                </div>
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">Lọc</button>
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table align-items-center">
                            <thead>
                                <tr>
                                    <th>Số lượng khách hàng mới</th>
                                    <th>Số lượng khách hàng quay lại</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($newCustomers); ?></td>
                                    <td><?php echo e($returningCustomers); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/reports/customers.blade.php ENDPATH**/ ?>