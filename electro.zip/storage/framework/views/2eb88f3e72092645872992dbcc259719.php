<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- css -->
    <link rel="stylesheet" href="./public/assets/css/style.css">
    <!-- Thêm Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" />
    <!-- Angularjs -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="./public/assets/js/app.js"></script>
</head>

<body>
    <!-- header  -->
    <header>
        <div id="header">
            <div class="container">
                <div class="row align-items-center">
                    <!-- LOGO -->
                    <div class="col-xl-3 col-lg-3 col-md-12">
                        <a href="/" class="logo text-decoration-none text-light">
                            <img src="./public/uploads/logo.png" alt="Logo">
                        </a>
                    </div>
                    <!-- /LOGO -->
                    <!-- SEARCH BAR -->
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="header-search">
                            <form action="#" .$maloai method="post">
                                <input class="input" name="kyw" style=" padding: 10px; border-radius: 50px 0 0 50px;"
                                    placeholder="Nhập tìm kiếm..." name="kyw">
                                <button class="search-btn" name="timkiem">Tìm kiếm</button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->
                    <!-- Nút -->
                    <div class="col-xl-3 col-lg-3 col-md-6 ">
                        <div class="header-ctn d-flex  align-items-center p-0">
                            <!-- Yêu thích -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none text-light" id="cartDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="far fa-heart"></i>
                                    <span>Yêu thích</span>
                                    <span
                                        class="qty bg-danger text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 20px; height: 20px;">2</span>
                                </a>
                                <ul class="dropdown-menu menu-cart dropdown-menu-end" aria-labelledby="cartDropdown">
                                    <!-- Danh sách sản phẩm trong giỏ hàng -->
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="./public/uploads/iphone_15_pro_max_image.jpg"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">iPhone
                                                        15 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">29,295,300 VND</p>
                                                    <del style="font-size: 12px;">31,295,300 VND</del>

                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="./public/uploads/iphone_14_pro_max_image.jpg"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">iPhone
                                                        14 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">27,142,150 VND</p>
                                                    <del style="font-size: 12px;">29,142,150 VND</del>

                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <!-- Kết thúc danh sách sản phẩm -->

                                    <!-- Phân cách hoặc các phần khác trong dropdown -->
                                    <div class="btn-group w-100">
                                        <a class="btn btn-danger-custom btn-sm" href="#">Danh sách yêu thích</a>
                                    </div>

                                    <!-- Kết thúc phần khác trong dropdown -->
                                </ul>
                            </div>
                            <!-- /Yêu thích -->
                            <!-- Giỏ hàng -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none text-light" id="cartDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-shopping-cart"></i>
                                    <span
                                        class="qty bg-danger text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 20px; height: 20px;">2</span>
                                    <span>Giỏ hàng</span>
                                </a>
                                <ul class="dropdown-menu menu-cart dropdown-menu-end" aria-labelledby="cartDropdown">
                                    <!-- Danh sách sản phẩm trong giỏ hàng -->
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="./public/uploads/iphone_15_pro_max_image.jpg"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">Iphone
                                                        15 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">29,295,300 VND</p>
                                                    <del style="font-size: 12px;">31,295,300 VND</del>
                                                    <samp class="text-end">2x</samp>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <!-- Kết thúc danh sách sản phẩm -->

                                    <!-- Phân cách hoặc các phần khác trong dropdown -->
                                    <div class="btn-group w-100">
                                        <a class="btn bg-primary-custom btn-sm" href="#">Xem giỏ hàng</a>
                                        <a class="btn btn-danger-custom btn-sm" href="#">Thanh toán <i
                                                class="fa fa-arrow-circle-right"></i></a>
                                    </div>

                                    <!-- Kết thúc phần khác trong dropdown -->
                                </ul>
                            </div>
                            <!-- /Giỏ hàng -->
                            <!-- Dropdown user -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none " id="dropdownUser2" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <img src="https://github.com/mdo.png" alt="mdo" 
                                        class="rounded-circle w-50">
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end text-small text-user"
                                    aria-labelledby="dropdownUser2">
                                    <li><a class="dropdown-item " href="#">Đơn hàng của tôi</a></li>
                                    <li><a class="dropdown-item" href="#">Hồ sơ</a></li>
                                    <li><a class="dropdown-item" href="#">Đổi mật khẩu</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="login.html">Đăng nhập</a></li>
                                    <li><a class="dropdown-item" href="register.html">Đăng Ký</a></li>
                                    <li><a class="dropdown-item" href="#">Đăng xuất</a></li>
                                </ul>

                            </div>
                            <!-- /Dropdown user -->
                        </div>
                    </div>
                    <!-- /Nút -->
                </div>
            </div>
        </div>
    </header>
    <!-- header  -->

    <!-- NAVIGATION -->
    <nav class="navbar navbar-expand-md ">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll"
                aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarScroll">
                <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                    <li class="nav-item px-2">
                        <a class="nav-link" href="index.html">Trang chủ</a>
                    </li>
                    <li class="nav-item px-2">
                        <a class="nav-link " href="products.html">Sản Phẩm</a>
                    </li>
                    <li class="nav-item px-2">
                        <a class="nav-link" href="#">Giới Thiệu</a>
                    </li>
                    <li class="nav-item px-2">
                        <a class="nav-link" href="#">Liên Hệ</a>
                    </li>
                    <li class="nav-item px-2">
                        <a class="nav-link" href="#">Góp Ý</a>
                    </li>
                    <li class="nav-item px-2">
                        <a class="nav-link" href="#">Hỏi Đáp</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- /NAVIGATION -->
    <!-- contetnt  -->


    <!-- contetnt  -->
    <!-- banner -->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="./public/uploads/banner1.webp" class="d-block w-100"
                    alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                <h5>First slide label</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div> -->
            </div>
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="./public/uploads/banner2.webp" class="d-block w-100"
                    alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                <h5>First slide label</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div> -->
            </div>
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="./public/uploads/banner3.webp" class="d-block w-100"
                    alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                <h5>First slide label</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div> -->
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- end banner -->

    <!-- product  -->
    <div class="container content p-0">
        <!-- section title -->
        <div class="col-md-12 ">
            <div class="section-title my-4">
                <h3 class="title">Sản Phẩm Mới</h3>
            </div>
        </div>
        <!-- /section title -->
        <div class="row  g-4 w-100 ">
            <div class="col-xl-3 col-md-4 col-sm-6  ">
                <div class="card rounded-0">
                    <a href="productDetail1.html">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_15_series_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="productDetail1.html" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Series
                        </a>
                        <p class="card-text m-0">22,835,850 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">24,835,850 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="productDetail2.html">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_15_plus_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Plus
                        </a>
                        <p class="card-text m-0">24,989,000 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">26,989,000 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="productDetail3.html">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_15_pro_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Pro
                        </a>
                        <p class="card-text m-0">27,142,150 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">29,142,150 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_15_pro_max_image.jpg" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Pro Max
                        </a>
                        <p class="card-text m-0">29,295,300 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">31,295,300 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="section-title my-4">
                <h3 class="title">Sản Phẩm Hot</h3>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-4 g-4 w-100">
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="san-pham-chi-tiet">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_13_pro_max_image.jpg" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="san-pham-chi-tiet" class="text-decoration-none text-dark-custom product-name ">
                            iphone 13 pro max
                        </a>
                        <p class="card-text m-0">24.000.000 đ</p>
                        <div class="price-sale">
                            <del class="product-old-price">95.000.000 </del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_14_pro_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            Iphone 14 pro
                        </a>
                        <p class="card-text m-0">28.000.000 đ</p>
                        <div class="price-sale">
                            <del class="product-old-price">95.000.000 </del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_14_pro_max_image.jpg" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            iphone 14 pro max
                        </a>
                        <p class="card-text m-0">34.000.000 đ</p>
                        <div class="price-sale">
                            <del class="product-old-price">95.000.000 </del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/iphone_15_pro_max_image.jpg" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            iphone 15 pro max
                        </a>
                        <p class="card-text m-0">100.000.000</p>
                        <div class="price-sale">
                            <del class="product-old-price">95.000.000 </del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="section-title my-4">
                <h3 class="title">Phụ kiện</h3>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-4 g-4 w-100">
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="san-pham-chi-tiet">
                        <div class="product-img">
                            <img src="./public/uploads/airpods_pro_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="san-pham-chi-tiet" class="text-decoration-none text-dark-custom product-name ">
                            AirPods Pro
                        </a>
                        <p class="card-text m-0">4,290,000 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">6,290,000 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/apple_watch_series_7_image.jpg" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            Apple Watch Series 7
                        </a>
                        <p class="card-text m-0">11,990,000 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">13,990,000 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/magic_keyboard_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            Magic Keyboard
                        </a>
                        <p class="card-text m-0">3,290,000 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">5,290,000 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6 ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="./public/uploads/magic_mouse_2_image.jpg" class="card-img-top" alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="" class="text-decoration-none text-dark-custom product-name ">
                            Magic Mouse 2
                        </a>
                        <p class="card-text m-0">1,590,000 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">3,590,000 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger-custom"> <i class="fa fa-shopping-cart me-1 ">Mua
                                        ngay</i></button>
                            </a>
                            <button class="btn btn-danger-custom"> <i class="fas fa-heart me-1"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end  product  -->

    <!-- end contetnt  -->

    <!-- FOOTER -->
    <footer id="footer" class="py-5 mt-5">
        <!-- top footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-md-4 col-sm-6 ">
                    <div class="footer">
                        <h3 class="footer-title">Về chúng tôi</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.</p>
                        <ul class="list-unstyled footer-links">
                            <li><i class="fas fa-map-marker-alt"></i> 1734 Stonecoal Road</li>
                            <li><i class="fas fa-phone"></i>+021-95-51-84</li>
                            <li><i class="fas fa-envelope"></i> email@email.com</li>

                        </ul>
                    </div>
                </div>

                <div class="col-xl-3 col-md-4 col-sm-6 ">
                    <div class="footer">
                        <h3 class="footer-title">Danh mục</h3>
                        <ul class="list-unstyled footer-links">
                            <li><a href="#">Hot deals</a></li>
                            <li><a href="#">Laptops</a></li>
                            <li><a href="#">Smartphones</a></li>
                            <li><a href="#">Cameras</a></li>
                            <li><a href="#">Accessories</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-xl-3 col-md-4 col-sm-6 ">
                    <div class="footer">
                        <h3 class="footer-title">Thông tin</h3>
                        <ul class="list-unstyled footer-links">
                            <li><a href="#">Về chúng tôi</a></li>
                            <li><a href="#">Liên hệ chúng tôi</a></li>
                            <li><a href="#">Chính sách bảo mật</a></li>
                            <li><a href="#">Đơn hàng và Trả hàng</a></li>
                            <li><a href="#">Điều khoản & Điều kiện</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-xl-3 col-md-4 col-sm-6 ">
                    <div class="footer">
                        <h3 class="footer-title">Dịch vụ</h3>
                        <ul class="list-unstyled footer-links">
                            <li><a href="#">Tài khoản của tôi</a></li>
                            <li><a href="#">Xem Giỏ hàng</a></li>
                            <li><a href="#">Danh sách mong muốn</a></li>
                            <li><a href="#">Theo dõi Đơn hàng của tôi</a></li>
                            <li><a href="#">Trợ giúp</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- /top footer -->
    </footer>

    <!-- /FOOTER -->
    <!-- Link to Bootstrap JS (Optional, only if you need JS components) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/clients/home.blade.php ENDPATH**/ ?>