
<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h3 class="title mb-1">Danh sách yêu thích</h3>
    <ul class="list-group">
        <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <img src="<?php echo e(asset('images/' . $favorite->product->image_url)); ?>" class="img-thumbnail" alt="<?php echo e($favorite->product->name); ?>" style="width: 100px; height: 100px;">
                <div class="ms-3">
                    <h5><?php echo e($favorite->product->name); ?></h5>
                </div>
            </div>
            <button class="btn btn-danger remove-favorite" data-id="<?php echo e($favorite->product_id); ?>">Xóa</button>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var removeButtons = document.querySelectorAll('.remove-favorite');

        removeButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var productId = this.getAttribute('data-id');
                var self = this;

                fetch(`/favorites/${productId}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.success);
                        self.closest('li').remove();
                    } else {
                        alert(data.error);
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/client/favorites.blade.php ENDPATH**/ ?>