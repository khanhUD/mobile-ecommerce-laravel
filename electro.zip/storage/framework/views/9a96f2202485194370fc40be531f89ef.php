<header>
        <div id="header">
            <div class="container">
                <div class="row align-items-center">
                    <!-- LOGO -->
                    <div class="col-xl-3 col-lg-3 col-md-12">
                        <a href="/" class="logo text-decoration-none text-light">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
                        </a>
                    </div>
                    <!-- /LOGO -->
                    <!-- SEARCH BAR -->
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="header-search">
                            <form action="#" .$maloai method="post">
                                <input class="input" name="kyw" style=" padding: 10px; border-radius: 50px 0 0 50px;"
                                    placeholder="Nhập tìm kiếm..." name="kyw">
                                <button class="search-btn" name="timkiem">Tìm kiếm</button>
                            </form>
                        </div>
                    </div>
                    <!-- /SEARCH BAR -->
                    <!-- Nút -->
                    <div class="col-xl-3 col-lg-3 col-md-6 ">
                        <div class="header-ctn d-flex  align-items-center p-0">
                            <!-- Yêu thích -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none text-light" id="cartDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="far fa-heart"></i>
                                    <span>Yêu thích</span>
                                    <span
                                        class="qty bg-danger text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 20px; height: 20px;">2</span>
                                </a>
                                <ul class="dropdown-menu menu-cart dropdown-menu-end" aria-labelledby="cartDropdown">
                                    <!-- Danh sách sản phẩm trong giỏ hàng -->
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="<?php echo e(asset('images/iphone_15_pro_max_image.jpg')); ?>"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">iPhone
                                                        15 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">29,295,300 VND</p>
                                                    <del style="font-size: 12px;">31,295,300 VND</del>

                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="<?php echo e(asset('images/iphone_14_pro_max_image.jpg')); ?>"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">iPhone
                                                        14 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">27,142,150 VND</p>
                                                    <del style="font-size: 12px;">29,142,150 VND</del>

                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <!-- Kết thúc danh sách sản phẩm -->

                                    <!-- Phân cách hoặc các phần khác trong dropdown -->
                                    <div class="btn-group w-100">
                                        <a class="btn btn-danger-custom btn-sm" href="#">Danh sách yêu thích</a>
                                    </div>

                                    <!-- Kết thúc phần khác trong dropdown -->
                                </ul>
                            </div>
                            <!-- /Yêu thích -->
                            <!-- Giỏ hàng -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none text-light" id="cartDropdown" role="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-shopping-cart"></i>
                                    <span
                                        class="qty bg-danger text-white rounded-circle d-flex align-items-center justify-content-center"
                                        style="width: 20px; height: 20px;">2</span>
                                    <span>Giỏ hàng</span>
                                </a>
                                <ul class="dropdown-menu menu-cart dropdown-menu-end" aria-labelledby="cartDropdown">
                                    <!-- Danh sách sản phẩm trong giỏ hàng -->
                                    <li class="mb-3">
                                        <a class="" href="#">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="#">
                                                        <div class="">
                                                            <img src="<?php echo e(asset('images/iphone_15_pro_max_image.jpg')); ?>"
                                                                class="card-img-top" alt="Product 1">
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-md-8">
                                                    <a href="#"
                                                        class="text-decoration-none text-dark-custom product-widget-name">Iphone
                                                        15 Pro Max</a>
                                                    <p style="font-size: 14px;" class="card-text m-0">29,295,300 VND</p>
                                                    <del style="font-size: 12px;">31,295,300 VND</del>
                                                    <samp class="text-end">2x</samp>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <!-- Kết thúc danh sách sản phẩm -->

                                    <!-- Phân cách hoặc các phần khác trong dropdown -->
                                    <div class="btn-group w-100">
                                        <a class="btn bg-primary-custom btn-sm" href="#">Xem giỏ hàng</a>
                                        <a class="btn btn-danger-custom btn-sm" href="#">Thanh toán <i
                                                class="fa fa-arrow-circle-right"></i></a>
                                    </div>

                                    <!-- Kết thúc phần khác trong dropdown -->
                                </ul>
                            </div>
                            <!-- /Giỏ hàng -->
                            <!-- Dropdown user -->
                            <div class="dropdown">
                                <a href="#" class="text-decoration-none " id="dropdownUser2" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <img src="<?php echo e(asset('images/no_image.jpg')); ?>" alt="mdo" 
                                        class="rounded-circle w-50">
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end text-small text-user"
                                    aria-labelledby="dropdownUser2">
                                    <li><a class="dropdown-item " href="#">Đơn hàng của tôi</a></li>
                                    <li><a class="dropdown-item" href="#">Hồ sơ</a></li>
                                    <li><a class="dropdown-item" href="#">Đổi mật khẩu</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="login.html">Đăng nhập</a></li>
                                    <li><a class="dropdown-item" href="register.html">Đăng Ký</a></li>
                                    <li><a class="dropdown-item" href="#">Đăng xuất</a></li>
                                </ul>

                            </div>
                            <!-- /Dropdown user -->
                        </div>
                    </div>
                    <!-- /Nút -->
                </div>
            </div>
        </div>
    </header><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/components/client/header.blade.php ENDPATH**/ ?>