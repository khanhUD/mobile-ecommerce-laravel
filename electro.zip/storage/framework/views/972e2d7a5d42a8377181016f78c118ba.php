
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container content p-0">
    <!-- section title -->
    <div class="col-md-12 ">
        <div class="section-title my-4">
            <h3 class="title">Sản Phẩm Mới</h3>
        </div>
    </div>
    <!-- /section title -->

    <!-- Product  -->
    <div class="row  g-4 w-100 ">
        <div class="col-xl-3 col-md-4 col-sm-6  ">
            <div class="card rounded-0">
                <a href="#">
                    <div class="product-img">
                        <img src="<?php echo e(asset('uploads/iphone_15_series_image.jpg')); ?>" class="card-img-top" alt="Product 1">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a href="#" class="text-decoration-none text-dark-custom product-name ">
                        iPhone 15 Series
                    </a>
                    <p class="card-text m-0">22,835,850 VND</p>
                    <div class="price-sale">
                        <del class="product-old-price">24,835,850 VND</del>
                    </div>
                    <div class="product-line">
                    </div>
                    <div class="product-btn">
                        <a href="#" class="text-decoration-none">
                            <button class="btn btn-danger">
                                <i class="fa fa-shopping-cart me1"></i>
                                <span class="small">Giỏ hàng</span>
                            </button>
                        </a>
                        <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu thích</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6  ">
            <div class="card rounded-0">
                <a href="#">
                    <div class="product-img">
                        <img src="<?php echo e(asset('uploads/iphone_15_series_image.jpg')); ?>" class="card-img-top" alt="Product 1">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a href="#" class="text-decoration-none text-dark-custom product-name ">
                        iPhone 15 Series
                    </a>
                    <p class="card-text m-0">22,835,850 VND</p>
                    <div class="price-sale">
                        <del class="product-old-price">24,835,850 VND</del>
                    </div>
                    <div class="product-line">
                    </div>
                    <div class="product-btn">
                        <a href="#" class="text-decoration-none">
                            <button class="btn btn-danger">
                                <i class="fa fa-shopping-cart me1"></i>
                                <span class="small">Giỏ hàng</span>
                            </button>
                        </a>
                        <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu thích</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6  ">
            <div class="card rounded-0">
                <a href="#">
                    <div class="product-img">
                        <img src="<?php echo e(asset('uploads/iphone_15_series_image.jpg')); ?>" class="card-img-top" alt="Product 1">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a href="#" class="text-decoration-none text-dark-custom product-name ">
                        iPhone 15 Series
                    </a>
                    <p class="card-text m-0">22,835,850 VND</p>
                    <div class="price-sale">
                        <del class="product-old-price">24,835,850 VND</del>
                    </div>
                    <div class="product-line">
                    </div>
                    <div class="product-btn">
                        <a href="#" class="text-decoration-none">
                            <button class="btn btn-danger">
                                <i class="fa fa-shopping-cart me1"></i>
                                <span class="small">Giỏ hàng</span>
                            </button>
                        </a>
                        <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu thích</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-4 col-sm-6  ">
            <div class="card rounded-0">
                <a href="#">
                    <div class="product-img">
                        <img src="<?php echo e(asset('uploads/iphone_15_series_image.jpg')); ?>" class="card-img-top" alt="Product 1">
                    </div>
                </a>
                <div class="card-body text-center">
                    <a href="#" class="text-decoration-none text-dark-custom product-name ">
                        iPhone 15 Series
                    </a>
                    <p class="card-text m-0">22,835,850 VND</p>
                    <div class="price-sale">
                        <del class="product-old-price">24,835,850 VND</del>
                    </div>
                    <div class="product-line">
                    </div>
                    <div class="product-btn">
                        <a href="#" class="text-decoration-none">
                            <button class="btn btn-danger">
                                <i class="fa fa-shopping-cart me1"></i>
                                <span class="small">Giỏ hàng</span>
                            </button>
                        </a>
                        <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu thích</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product  -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/client/home.blade.php ENDPATH**/ ?>