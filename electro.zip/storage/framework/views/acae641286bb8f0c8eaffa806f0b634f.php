<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="/dang-xuat" method="post">
        <?php echo csrf_field(); ?> <!-- Thêm CSRF token để bảo vệ form từ tấn công CSRF -->
        <button type="submit" name="submit">Đăng xuất</button>
    </form>
</body>
<?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel_copy\electro\resources\views/admin/mains/home.blade.php ENDPATH**/ ?>