
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-7 mb-3">
                <?php if($cart && $cart->items->count() > 0): ?>
                    <div class="table-responsive">
                        <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Sản phẩm</th>
                                        <th>Giá</th>
                                        <th>Số lượng</th>
                                        <th>Tạm tính</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="col-2 d-flex align-items-center">
                                                    <button type="button"
                                                        class="btn btn-outline-danger btn-sm rounded-circle"
                                                        onclick="removeItem(<?php echo e($item->id); ?>)">&times;</button>
                                                </div>
                                            </td>
                                            <td class="col-6 align-content-center">
                                                <div class="row">
                                                    <div class="col-3 p-0">
                                                        <img src="<?php echo e(asset('images/' . $item->product->image_url)); ?>"
                                                            alt="<?php echo e($item->product->name); ?>" class="img-fluid rounded">
                                                    </div>
                                                    <div class="col-8">
                                                        <span class="d-block"><?php echo e($item->product->name); ?></span>
                                                        <?php if($item->variant): ?>
                                                            <?php $__currentLoopData = $item->variant->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="d-block text-muted">
                                                                    <?php echo e($attribute->attribute->attribute_name); ?>:
                                                                    <?php echo e($attribute->attribute_value); ?></span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="col-2 align-content-center">
                                                <?php echo e(number_format($item->price, 0, ',', '.')); ?>₫
                                            </td>
                                            <td class="col-2 align-content-center">
                                                <input type="number" name="items[<?php echo e($item->id); ?>]" class="form-control"
                                                    value="<?php echo e($item->quantity); ?>" min="1">
                                            </td>
                                            <td class="col-2 align-content-center">
                                                <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?>₫
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </form>
                    </div>
                <?php else: ?>
                    <p>Giỏ hàng của bạn hiện đang trống.</p>
                    <a href="<?php echo e(route('home.index')); ?>">
                        <div class="btn btn-danger">Quay về trang chủ</div>
                    </a>
                <?php endif; ?>
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('productsClient.index')); ?>" class="btn btn-outline-danger">&larr; Tiếp
                        tục xem sản phẩm</a>
                    <button type="submit" class="btn btn-danger">Cập nhật giỏ hàng</button>
                </div>
            </div>
            <div class="col-md-5">
                <?php if($cart && $cart->items->count() > 0): ?>
                    <div class="p-3 bg-light border rounded">
                        <h5 class="border-bottom pb-2">Cộng giỏ hàng</h5>
                        <div class="d-flex justify-content-between">
                            <span>Tạm tính</span>
                            <span><?php echo e(number_format($cart->items->sum(function ($item) {return $item->price * $item->quantity;}),0,',','.')); ?>₫</span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Mã giảm giá (GIAM20%)</span>
                        </div>
                        <div class="d-flex justify-content-between border-top pt-2">
                            <strong>Tổng</strong>
                            <strong><?php echo e(number_format($cart->items->sum(function ($item) {return $item->price * $item->quantity;}) - 0,0,',','.')); ?>₫</strong>
                        </div>
                        <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-danger btn-block mt-3">Tiến hành thanh
                            toán</a>
                    </div>
                    <div class="mt-3">
                        <label for="promoCode" class="form-label">Phiếu ưu đãi</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="promoCode" placeholder="Mã ưu đãi">
                            <button class="btn btn-secondary">Áp dụng</button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function removeItem(itemId) {
            if (confirm('Bạn có chắc chắn muốn xóa sản phẩm này khỏi giỏ hàng?')) {
                fetch(`/cart/remove/${itemId}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Content-Type': 'application/json',
                        },
                    })
                    .then(response => {
                        if (response.ok) {
                            location.reload();
                        } else {
                            alert('Đã có lỗi xảy ra, vui lòng thử lại.');
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/client/cart.blade.php ENDPATH**/ ?>