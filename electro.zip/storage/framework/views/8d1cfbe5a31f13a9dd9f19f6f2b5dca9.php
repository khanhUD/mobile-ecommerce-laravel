
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 ">
                        <div
                            class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
                            <h5 class="text-white text-capitalize ps-3"><?php echo e($title); ?></h5>
                            <a href="<?php echo e(route('menu.create')); ?>"><button type="button"
                                    class="btn btn-primary text-capitalize me-4">
                                    Thêm mới
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">

                                <tbody>
                                    <?php if($menus->isEmpty()): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Chưa có menu</td>
                                        </tr>
                                    <?php else: ?>
                                        <thead>
                                            <tr>
                                                <th
                                                    class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                    Tên
                                                </th>
                                                <th
                                                    class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                                    Danh mục cha</th>
                                                <th
                                                    class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                                    Slug</th>
                                                <th
                                                    class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">
                                                    Trạng thái</th>
                                                <th class="text-secondary opacity-7"></th>
                                            </tr>
                                        </thead>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <h6 class=" px-3 mb-0 text-sm"><?php echo e($menu->name); ?></h6>
                                                </td>
                                                <td>
                                                    <?php if($menu->parent): ?>
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo e($menu->parent->name); ?>

                                                        </p>
                                                    <?php else: ?>
                                                        <p class="text-xs font-weight-bold mb-0">Không có</p>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <p class="text-xs font-weight-bold mb-0"><?php echo e($menu->slug); ?> </p>
                                                </td>
                                                <td class="align-middle text-center text-sm">
                                                    <span
                                                        class="badge badge-sm <?php echo e($menu->status == 1 ? 'bg-gradient-success' : 'bg-gradient-danger'); ?>">
                                                        <?php echo e($menu->status == 1 ? 'Hiển thị' : 'Ẩn'); ?>

                                                    </span>
                                                </td>

                                                <td class="align-middle text-center d-flex justify-content-center">
                                                    <a href="<?php echo e(route('menu.edit', $menu->id)); ?>">
                                                        <button type="button"
                                                            class="btn btn-warning text-capitalize text-xs mb-0 me-2">
                                                            Sửa
                                                        </button>
                                                    </a>
                                                    <form id="delete-form-<?php echo e($menu->id); ?>"
                                                        action="<?php echo e(route('menu.destroy', $menu->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="button" onclick="confirmDelete(<?php echo e($menu->id); ?>)"
                                                            class="btn btn-danger text-capitalize text-xs mb-0">
                                                            Xóa
                                                        </button>
                                                    </form>
                                                    <script>
                                                        function confirmDelete(id) {
                                                            if (confirm('Bạn có chắc muốn xóa?')) {
                                                                document.getElementById('delete-form-' + id).submit();
                                                            }
                                                        }
                                                    </script>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/menus/index.blade.php ENDPATH**/ ?>