
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3 ">
                        <div
                            class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
                            <h5 class="text-white text-capitalize ps-3"><?php echo e($title); ?></h5>
                            <a href="<?php echo e(route('attributes.create')); ?>"><button type="button"
                                    class="btn btn-primary text-capitalize me-4">
                                    Thêm mới
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">

                                <tbody>
                                    <?php if($attributes->isEmpty()): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Chưa có thuộc tính</td>
                                        </tr>
                                    <?php else: ?>
                                        <thead>
                                            <tr>
                                            <tr>
                                                <th
                                                    class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                    Tên
                                                    Loại Sản Phẩm</th>
                                                <th
                                                    class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                                    Ngày tạo</th>
                                                <th class="text-secondary opacity-7"></th>
                                            </tr>
                                            </tr>
                                        </thead>
                                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <h6 class="px-3 mb-0 text-sm"><?php echo e($attribute->attribute_name); ?></h6>
                                                </td>

                                                <td class="align-middle text-center text-sm">
                                                    <span
                                                        class=""><?php echo e($attribute->created_at->format('d/m/Y')); ?></span>
                                                </td>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="<?php echo e(route('attributes.edit', $attribute->id)); ?>">
                                                            <button type="button"
                                                                class="btn btn-warning text-capitalize text-xs mb-0 me-2">Sửa</button>
                                                        </a>
                                                        <form id="delete-form-<?php echo e($attribute->id); ?>"
                                                            action="<?php echo e(route('attributes.destroy', $attribute->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="button"
                                                                onclick="confirmDelete('<?php echo e($attribute->id); ?>')"
                                                                class="btn btn-danger text-capitalize text-xs mb-0">Xóa
                                                            </button>
                                                        </form>
                                                    </div>
                                                    <script>
                                                        function confirmDelete(id) {
                                                            if (confirm('Bạn có chắc muốn xóa?')) {
                                                                document.getElementById('delete-form-' + id).submit();
                                                            }
                                                        }
                                                        // 
                                                        $(document).ready(function() {
                                                            $('.toggle-status').click(function() {
                                                                var button = $(this);
                                                                var attributeId = button.data('id');
                                                                var currentStatus = button.data('status');
                                                                var newStatus = currentStatus == 1 ? 0 : 1;

                                                                // Lấy CSRF Token từ thẻ meta
                                                                var csrfToken = $('meta[name="csrf-token"]').attr('content');

                                                                $.ajax({
                                                                    url: '/admin/thuoc-tinh/sua-trang-thai/' + attributeId,
                                                                    type: 'PUT',
                                                                    data: {
                                                                        status: newStatus,
                                                                        _token: csrfToken // Thêm CSRF Token vào dữ liệu gửi
                                                                    },

                                                                    success: function(response) {
                                                                        // Cập nhật trạng thái và văn bản của nút
                                                                        button.data('status', newStatus);
                                                                        button.text(newStatus == 1 ? 'Hiển thị' : 'Ẩn');

                                                                        // Xóa lớp màu của nút hiện tại
                                                                        button.removeClass('btn-success btn-danger');

                                                                        // Thêm lớp màu mới cho nút dựa trên trạng thái mới
                                                                        if (newStatus == 1) {
                                                                            button.addClass('btn-success');
                                                                        } else {
                                                                            button.addClass('btn-danger');
                                                                        }
                                                                    },
                                                                    error: function() {
                                                                        alert('Đã xảy ra lỗi khi cập nhật trạng thái.');
                                                                    }
                                                                });
                                                            });
                                                        });
                                                    </script>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/attributes/index.blade.php ENDPATH**/ ?>