

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3">
                        <div
                            class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
                            <h5 class="text-white text-capitalize ps-3">Chi tiết sản phẩm</h5>
                            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary text-capitalize me-4">
                                Danh sách
                            </a>
                        </div>
                    </div>
                    <div class="row gx-4 mt-2 m-0">
                        <div class="col-auto">
                            <div class="avatar avatar-xl position-relative">
                                <img src="<?php echo e(asset('images/' . $product->image_url)); ?>" alt="<?php echo e($product->image_url); ?>"
                                    class="w-100 border-radius-lg shadow-sm">
                            </div>
                        </div>
                        <div class="col-auto my-auto">
                            <div class="h-100">
                                <h5 class="mb-1">
                                    <?php echo e($product->name); ?>

                                </h5>
                                <p class="mb-0 font-weight-normal text-sm">
                                    <span class="product-details-price"><?php echo e($product->price_range); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <?php if($product->has_variants === 1): ?>
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tên
                                            biến thể</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Màu</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Dung lượng</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Số lượng</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex px-2 py-1">
                                                    <div>
                                                        <img src="<?php echo e(asset('images/' . $variation->image_url)); ?>"
                                                            class="avatar avatar-sm me-3 border-radius-lg"
                                                            alt="variant_image">
                                                    </div>
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($variation->variant_name); ?></h6>
                                                        <p class="text-xs text-secondary mb-0">
                                                            <?php echo e(number_format($variation->price, 0, '.', '.')); ?> VND</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0">
                                                    <?php echo e($variation->attributes->where('attribute_id', 1)->first()->attribute_value ?? 'N/A'); ?>

                                                </p>
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0">
                                                    <?php echo e($variation->attributes->where('attribute_id', 2)->first()->attribute_value ?? 'N/A'); ?>GB
                                                </p>
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0"><?php echo e($variation->stock); ?></p>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>    
                            <?php endif; ?>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row container">
            <div>
                <div class="row mb-3">
                    <div class="col-md-6 col-sm-9">
                        
                        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-indicators">
                                <?php $__currentLoopData = $subImagePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subImagePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button" data-bs-target="#carouselExampleIndicators"
                                        data-bs-slide-to="<?php echo e($key); ?>"
                                        <?php if($loop->first): ?> class="active" <?php endif; ?>></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $subImagePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subImagePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
                                        <img src="<?php echo e(asset('images/' . $subImagePath)); ?>" class="d-block w-100"
                                            alt="<?php echo e($subImagePath); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                                data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Trước</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                                data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Tiếp</span>
                            </button>
                        </div>
                        

                    </div>
                    <div class="col-md-6">
                        <div class="product-details ">
                            <h4 class="text-uppercase product-details-name">
                                <?php echo e($product->name); ?>

                            </h4>
                            <div>
                                <h3 id="product-price"><?php echo e($product->price_range); ?></h3>
                            </div>
                            <p>
                                <a class="category-detail text-decoration-none text-hover" href="">Danh mục:
                                    <?php echo e($product->category->category_name); ?></a>
                            </p>
                            <div class="row mb-3">
                                <?php
                                    $displayedCapacities = [];
                                ?>
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $capacity =
                                            $variant->attributes->where('attribute_id', 2)->first()->attribute_value ??
                                            'N/A';
                                    ?>
                                    <?php if(!in_array($capacity, $displayedCapacities)): ?>
                                        <div class="col-md-2 mb-3">
                                            <div class="option-group">
                                                <div class="option" data-capacity="<?php echo e($capacity); ?>">
                                                    <?php echo e($capacity); ?></div>
                                            </div>
                                        </div>
                                        <?php
                                            $displayedCapacities[] = $capacity;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if($product->has_variants === 1): ?>
                            <div class="row mb-3">
                                <?php
                                    $displayedColors = [];
                                ?>
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $color =
                                            $variant->attributes->where('attribute_id', 1)->first()->attribute_value ??
                                            'N/A';
                                    ?>
                                    <?php if(!in_array($color, $displayedColors)): ?>
                                        <div class="col-md-2 mb-3">
                                            <div class="option-group">
                                                <div class="color-option" data-color="<?php echo e($color); ?>">
                                                    <img src="<?php echo e(asset('images/' . $variant->image_url)); ?>" class="w-100"
                                                        alt="<?php echo e($variant->image_url); ?>">
                                                    <span> <?php echo e($color); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                            $displayedColors[] = $color;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>  
                            <?php endif; ?>
                         
                            <p class="mb-1">Kho: <span id="product-stock"><?php echo e($product->total_stock); ?></span></p>
                            <p><?php echo $product->short_description; ?></p>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-7">
                        
                        <p><?php echo $product->long_description; ?></p>
                        
                    </div>
                    <div class="col-md-5">
                        <p><?php echo $product->specifications; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const variants = <?php echo json_encode($product->variants, 15, 512) ?>;

            document.querySelectorAll('.option, .color-option').forEach(option => {
                option.addEventListener('click', function() {
                    if (option.classList.contains('option')) {
                        document.querySelectorAll('.option').forEach(el => el.classList.remove(
                            'selected'));
                    } else if (option.classList.contains('color-option')) {
                        document.querySelectorAll('.color-option').forEach(el => el.classList
                            .remove('selected'));
                    }
                    option.classList.add('selected');

                    const selectedCapacity = document.querySelector('.option.selected')?.dataset
                        .capacity;
                    const selectedColor = document.querySelector('.color-option.selected')?.dataset
                        .color;

                    if (selectedCapacity && selectedColor) {
                        const selectedVariant = variants.find(variant => {
                            const capacity = variant.attributes.find(attr => attr
                                .attribute_id == 2)?.attribute_value;
                            const color = variant.attributes.find(attr => attr
                                .attribute_id == 1)?.attribute_value;
                            return capacity == selectedCapacity && color == selectedColor;
                        });

                        if (selectedVariant) {
                            document.getElementById('product-price').textContent = new Intl
                                .NumberFormat().format(selectedVariant.price) + ' VND';
                            document.getElementById('product-stock').textContent = selectedVariant
                                .stock;
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/products/detail.blade.php ENDPATH**/ ?>