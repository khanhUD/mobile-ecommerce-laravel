<?php $__env->startComponent('mail::message'); ?>
# Cảm ơn bạn đã đặt hàng

Xin chào <?php echo e($order->full_name); ?>,

Đơn hàng #<?php echo e($order->order_code); ?> đã được đặt thành công và chúng tôi đang xử lý.

**Phương thức thanh toán:** <?php echo e($order->payment_method == 'Cod' ? 'Trả tiền mặt khi nhận hàng' : 'Thanh toán qua VNPAY'); ?>


## [Đơn hàng #<?php echo e($order->order_code); ?>] (<?php echo e($order->created_at->format('d/m/Y')); ?>)

<?php $__env->startComponent('mail::table'); ?>
| Sản phẩm | Số lượng | Giá |
| -------- |:--------:| ---:|
<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
| <?php echo e($item->product_name); ?><br>
<?php if($item->variant): ?>
Dung Lượng: <?php echo e($item->variant->attributes->where('attribute_name', 'Dung Lượng')->first()->attribute_value ?? ''); ?><br>
Màu: <?php echo e($item->variant->attributes->where('attribute_name', 'Màu')->first()->attribute_value ?? ''); ?><br>
<?php endif; ?>
| <?php echo e($item->quantity); ?> | <?php echo e(number_format($item->price, 0, ',', '.')); ?>₫ |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->renderComponent(); ?>

### Tổng số phụ: <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?>₫
### Giảm giá: -<?php echo e(number_format($order->discount_amount, 0, ',', '.')); ?>₫
### Tổng cộng: <?php echo e(number_format($order->final_amount, 0, ',', '.')); ?>₫

## Địa chỉ thanh toán
<?php echo e($order->full_name); ?><br>
<?php echo e($order->ward); ?>, <?php echo e($order->district); ?>, <?php echo e($order->city); ?><br>
<?php echo e($order->address); ?><br>
<?php echo e($order->phone); ?><br>

## Địa chỉ giao hàng
<?php echo e($order->full_name); ?><br>
<?php echo e($order->ward); ?>, <?php echo e($order->district); ?>, <?php echo e($order->city); ?><br>
<?php echo e($order->address); ?><br>
<?php echo e($order->phone); ?><br>

Thanks for using <?php echo e(config('app.name')); ?>!
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/emails/order_invoice.blade.php ENDPATH**/ ?>