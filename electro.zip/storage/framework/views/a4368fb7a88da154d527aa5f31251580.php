

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
  <div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 ">
          <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 row d-flex align-items-center justify-content-between">
            <div class="col-auto">
              <h5 class="text-white text-capitalize">Danh sách banners</h5>
            </div>
            <div class="col-auto  ">
              <div class="row">
                <div class="col-auto ">
                  <div class="ms-md-auto d-flex align-items-center">
                    <div class="input-group input-group-outline">
                      <label class="form-label">Tìm kiếm...</label>
                      <input wire:model.debounce.350ms="search" type="search" class="form-control text-search">
                    </div>
                  </div>
                </div>
                <div class="col-auto">
                  <button type="button" wire:click='create' class="btn btn-primary text-capitalize mb-0 " >
                    <?php echo e($test); ?>

                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th wire:click="sortBy('title')" class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                    Tiêu đề
                  </th>
                  <th wire:click="sortBy('description')" class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                    Mô tả
                  </th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                    Ảnh
                  </th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                    Trạng thái
                  </th>
                  <th></th>
                </tr>

              </thead>
              <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <h6 class="px-3 mb-0 text-sm"><?php echo e($banner->title); ?></h6>
                  </td>
                  <td>
                    <p class="text-xs font-weight-bold mb-0"><?php echo e($banner->description); ?></p>
                  </td>
                  <td>
                    <div data-bs-toggle="modal" data-bs-target="#imageBannerModal">
                      <img src="<?php echo e(asset('uploads/' . $banner->image)); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                    </div>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <span class="badge badge-sm <?php echo e($banner->status == 1 ? 'bg-gradient-success' : 'bg-gradient-danger'); ?>">
                      <?php echo e($banner->status == 1 ? 'Hiển thị' : 'Ẩn'); ?>

                    </span>

                  </td>

                  <td class="align-middle text-center">
                    <button wire:click="edit(<?php echo e($banner->id); ?>)" type="button" class="btn btn-warning text-capitalize text-xs mb-0" data-bs-toggle="modal" data-id="<?php echo e($banner->id); ?>" data-bs-target="#editModal1">
                      Edit
                    </button>

                    <button type="button" class="btn btn-secondary text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editModal1">
                      Xóa
                    </button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <nav aria-label="Page navigation">
    <div class="align-items-center row justify-content-between ">
      <div class="col-auto">
        Hiển thị
        <select wire:model="perPage" wire:change="setPerPage($event.target.value)" class="form-select" aria-label="Default select example">
          <option value="5">5</option>
          <option value="7">7</option>
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
        sản phẩm mỗi trang
      </div>


      <ul class="col-auto pagination justify-content-end">
        <li class="page-item <?php echo e($banners->onFirstPage() ? 'disabled' : ''); ?>">
          <a class="page-link" href="<?php echo e($banners->previousPageUrl()); ?>" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
          </a>
        </li>
        <?php $__currentLoopData = $banners->getUrlRange(1, $banners->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="page-item <?php echo e($banners->currentPage() == $page ? 'active' : ''); ?>">
          <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="page-item <?php echo e(!$banners->hasMorePages() ? 'disabled' : ''); ?>">
          <a class="page-link" href="<?php echo e($banners->nextPageUrl()); ?>" aria-label="Next">
            <span aria-hidden="true">&raquo;</span>
          </a>
        </li>
      </ul>
    </div>

  </nav>



  <?php echo $__env->make('livewire.admin.banner.formAdd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('livewire.admin.banner.formEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Modal ảnh Banner -->
  <div class="modal fade modal-lg" id="imageBannerModal" tabindex="-1" aria-labelledby="imageBannerLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <img src="<?php echo e(asset('images/team-2.jpg')); ?>" alt="user1" class="w-100">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/livewire/admin/banner/bannerIndex.blade.php ENDPATH**/ ?>