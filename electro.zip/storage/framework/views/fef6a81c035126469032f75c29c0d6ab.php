
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="<?php echo e(asset('images/banner1.jpg')); ?>"
                    class="d-block w-100" alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div> -->
            </div>
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="<?php echo e(asset('images/banner2.webp')); ?>"
                    class="d-block w-100" alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div> -->
            </div>
            <div class="carousel-item active">
                <img style="height: 400px; object-fit: cover;" src="<?php echo e(asset('images/banner3.webp')); ?>"
                    class="d-block w-100" alt="...">
                <!-- <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div> -->
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div class="container content p-0">
        <!-- section title -->
        <div class="col-md-12 ">
            <div class="section-title my-4">
                <h3 class="title">Sản Phẩm Mới</h3>
            </div>
        </div>
        <!-- /section title -->

        <!-- Product  -->
        <div class="row  g-4 w-100 ">
            <div class="col-xl-3 col-md-4 col-sm-6  ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="<?php echo e(asset('images/iphone_15_series_image.jpg')); ?>" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="#" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Series
                        </a>
                        <p class="card-text m-0">22,835,850 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">24,835,850 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger">
                                    <i class="fa fa-shopping-cart me1"></i>
                                    <span class="small">Giỏ hàng</span>
                                </button>
                            </a>
                            <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu
                                    thích</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6  ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="<?php echo e(asset('images/iphone_15_series_image.jpg')); ?>" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="#" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Series
                        </a>
                        <p class="card-text m-0">22,835,850 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">24,835,850 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger">
                                    <i class="fa fa-shopping-cart me1"></i>
                                    <span class="small">Giỏ hàng</span>
                                </button>
                            </a>
                            <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span class="small">Yêu
                                    thích</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6  ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="<?php echo e(asset('images/iphone_15_series_image.jpg')); ?>" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="#" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Series
                        </a>
                        <p class="card-text m-0">22,835,850 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">24,835,850 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger">
                                    <i class="fa fa-shopping-cart me1"></i>
                                    <span class="small">Giỏ hàng</span>
                                </button>
                            </a>
                            <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span
                                    class="small">Yêu thích</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-4 col-sm-6  ">
                <div class="card rounded-0">
                    <a href="#">
                        <div class="product-img">
                            <img src="<?php echo e(asset('images/iphone_15_series_image.jpg')); ?>" class="card-img-top"
                                alt="Product 1">
                        </div>
                    </a>
                    <div class="card-body text-center">
                        <a href="#" class="text-decoration-none text-dark-custom product-name ">
                            iPhone 15 Series
                        </a>
                        <p class="card-text m-0">22,835,850 VND</p>
                        <div class="price-sale">
                            <del class="product-old-price">24,835,850 VND</del>
                        </div>
                        <div class="product-line">
                        </div>
                        <div class="product-btn">
                            <a href="#" class="text-decoration-none">
                                <button class="btn btn-danger">
                                    <i class="fa fa-shopping-cart me1"></i>
                                    <span class="small">Giỏ hàng</span>
                                </button>
                            </a>
                            <button class="btn btn-secondary"> <i class="fas fa-heart me-1 "></i> <span
                                    class="small">Yêu thích</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Product  -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/pages/client/home.blade.php ENDPATH**/ ?>