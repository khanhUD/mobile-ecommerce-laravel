

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layout.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
  <div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 ">
          <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
            <h5 class="text-white text-capitalize ps-3">Danh sách banners</h5>
            <button type="button" class="btn btn-primary text-capitalize me-4" data-bs-toggle="modal" data-bs-target="#addbannerModal">
              Thêm mới
            </button>
          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tiêu đề</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mô tả</th>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Ảnh</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Trạng thái</th>
                  <th class="text-secondary opacity-7"></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <h6 class=" px-3 mb-0 text-sm">Iphone 15</h6>
                  </td>
                  <td>
                    <p class="text-xs font-weight-bold mb-0">Iphone 12</p>
                  </td>
                  <td>
                    <div data-bs-toggle="modal" data-bs-target="#imageBannerModal">
                      <img src="<?php echo e(asset('assets/img/team-2.jpg')); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="user1">
                    </div>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <span class="badge badge-sm bg-gradient-success">Hiển thị</span>
                  </td>

                  <td class="align-middle">
                    <button type="button" class="btn btn-primary text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editModal1">
                      Edit
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Thêm Banner Modal -->
  <div class="modal fade" id="addbannerModal" tabindex="-1" aria-labelledby="addbannerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addbannerModalLabel">Thêm Banner</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="bannerAddForm">
            <input type="hidden" id="bannerId" name="bannerId">
            <div class="mb-3">
              <label for="title" class="form-label">Tiêu đề</label>
              <input type="text" class="form-control" id="title" name="title">
            </div>
            <div class="mb-3">
              <label for="description" class="form-label">Mô tả</label>
              <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="mb-3">
              <label for="image_path" class="form-label">Ảnh</label>
              <input type="file" class="form-control" id="image_path" name="image_path">
            </div>
            <div class="mb-3">
              <label for="status" class="form-label">Trạng thái</label><br>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                <label class="form-check-label" for="active">Hiển thị</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                <label class="form-check-label" for="inactive">Ẩn</label>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="button" class="btn btn-primary">Thêm</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <!-- Modal Sửa Banner -->
  <div class="modal fade modal-lg" id="editModal1" tabindex="-1" aria-labelledby="editModalLabel1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addbannerModalLabel">Sửa Banner</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="bannerForm">
            <input type="hidden" id="bannerId" name="bannerId">
            <div class="mb-3">
              <label for="title" class="form-label">Tiêu đề</label>
              <input type="text" class="form-control" id="title" name="title">
            </div>
            <div class="mb-3">
              <label for="description" class="form-label">Mô tả</label>
              <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="mb-3">
              <label for="image_path" class="form-label">Ảnh</label>
              <input type="file" class="form-control" id="image_path" name="image_path">
            </div>
            <div class="mb-3">
              <label for="status" class="form-label">Trạng thái</label><br>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                <label class="form-check-label" for="active">Hiển thị</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                <label class="form-check-label" for="inactive">Ẩn</label>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="button" class="btn btn-primary">Lưu</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <!-- Modal ảnh Banner -->
  <div class="modal fade modal-lg" id="imageBannerModal" tabindex="-1" aria-labelledby="imageBannerLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <img src="<?php echo e(asset('assets/img/team-2.jpg')); ?>" alt="user1">
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/admin/banners/list.blade.php ENDPATH**/ ?>