  <!-- Modal Sửa Banner -->
  <div class="modal fade modal-lg" id="editModal1" tabindex="-1" aria-labelledby="editModalLabel1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addbannerModalLabel">Sửa Banner</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="bannerForm">
            <input type="hidden" id="bannerId" name="bannerId">
            <div class="mb-3">
              <label for="title" class="form-label">Tiêu đề</label>
              <input type="text" class="form-control" id="title" name="title">
            </div>
            <div class="mb-3">
              <label for="description" class="form-label">Mô tả</label>
              <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="mb-3">
              <label for="image_path" class="form-label">Ảnh</label>
              <input type="file" class="form-control" id="image_path" name="image_path">
            </div>
            <div class="mb-3">
              <label for="status" class="form-label">Trạng thái</label><br>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                <label class="form-check-label" for="active">Hiển thị</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                <label class="form-check-label" for="inactive">Ẩn</label>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="button" class="btn btn-primary">Lưu</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal --><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel_livewire\electro\resources\views/pages/admin/banners/edit.blade.php ENDPATH**/ ?>