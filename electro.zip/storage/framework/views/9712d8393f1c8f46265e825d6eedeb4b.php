

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
  <div class="row">
    <div class="col-12">
      <div class="card my-4">
        <div class="card-header p-0 position-relative mt-n4 mx-3 ">
          <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
            <h5 class="text-white text-capitalize ps-3">Danh sách loại bài viết</h5>
            <button type="button" class="btn btn-primary text-capitalize me-4" data-bs-toggle="modal" data-bs-target="#addPostCategoriesModal">
              Thêm mới
            </button>

          </div>
        </div>
        <div class="card-body px-0 pb-2">
          <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Tên loại bài viết</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Trạng thái</th>
                  <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Ngày thêm</th>
                  <th class="text-secondary opacity-7"></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <p class="text-xs font-weight-bold mb-0 px-3">Du lịch</p>
                  </td>
                  <td class="align-middle text-center text-sm">
                    <span class="badge badge-sm bg-gradient-success">Hiển thị</span>
                  </td>
                  <td class="align-middle text-center">
                    <span class="text-secondary text-xs font-weight-bold">23/04/18</span>
                  </td>
                  <td class="align-middle">
                    <button type="button" class="btn btn-primary text-capitalize text-xs mb-0" data-bs-toggle="modal" data-bs-target="#editPostCategoriesModal">
                      Edit
                    </button>

                  </td>
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Thêm PostCategories Modal -->
  <div class="modal fade" id="addPostCategoriesModal" tabindex="-1" aria-labelledby="addPostCategoriesModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addPostCategoriesModalLabel">Thêm Loại bài viết</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="postCategoriesAddForm">
                    <input type="hidden" id="menuId" name="menuId">
                    <div class="mb-3">
                        <label for="name" class="form-label">Tên Loại bài viết</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>                 
                    <div class="mb-3">
                        <label for="status" class="form-label">Trạng Thái</label><br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                            <label class="form-check-label" for="active">Hiển Thị</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                            <label class="form-check-label" for="inactive">Ẩn</label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                <button type="button" class="btn btn-primary">Thêm</button>
            </div>
        </div>
    </div>
</div>
  <!-- Modal -->

  <!-- Sửa Loại bài viết Modal -->
  <div class="modal fade " id="editPostCategoriesModal" tabindex="-1" aria-labelledby="editPostCategoriesLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editPostCategoriesLabel">Sửa loại bài viết</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="postCategoriesEditForm">
            <input type="hidden" id="id" name="id">
            <div class="mb-3">
              <label for="name" class="form-label">Tên loại bài viết</label>
              <input type="text" class="form-control" id="name" name="name">
            </div>
            <div class="mb-3">
              <label for="status" class="form-label">Trạng thái</label><br>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="active" name="status" value="1" checked>
                <label class="form-check-label" for="active">Hiển thị</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" id="inactive" name="status" value="0">
                <label class="form-check-label" for="inactive">Ẩn</label>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          <button type="button" class="btn btn-primary">Lưu</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/pages/admin/postCategories/list.blade.php ENDPATH**/ ?>