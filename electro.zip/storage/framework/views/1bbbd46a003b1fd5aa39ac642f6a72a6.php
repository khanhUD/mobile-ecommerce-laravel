
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.client.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="section p-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 d-none d-md-block border-end">
                    <aside>
                        <div class="card">
                            <ul class="list-group btn-danger-custom">
                                <div class="card-header fw-bold text-uppercase">
                                    <i class="fas fa-list-ul me-2"></i>Danh mục
                                </div>
                                <a href="<?php echo e(route('productsClient.productByCategory')); ?>"
                                    class="list-group-item list-group-item-action">Tất Cả</a>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('productsClient.productByCategory', ['slug' => $category->slug])); ?>"
                                        class="list-group-item list-group-item-action"><?php echo e($category->category_name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </aside>
                    <aside>
                        <p class="my-3 fw-bold text-uppercase">Top sản phẩm yêu thích</p>
                        <?php $__currentLoopData = $mostViewedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-widget mb-3">
                                <div class="row">
                                    <div class="col-4 col-md-4">
                                        <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                                            <div class="">
                                                <img src="<?php echo e(asset('images/' . $product->image_url)); ?>"
                                                    class="card-img-top img-fluid" alt="<?php echo e($product->name); ?>">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-8 col-md-8">
                                        <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                            class="text-decoration-none text-dark-custom product-widget-name"><?php echo e($product->name); ?></a>
                                        <p style="font-size: 14px;" class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                        <?php if($product->old_price): ?>
                                            <del style="font-size: 12px;"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                                VND</del>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </aside>
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row g-3 mb-3">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-6">
                                <div class="card rounded-0 bg-hove">
                                    <a href="<?php echo e(route('productsClient.show', $product->id)); ?>">
                                        <div class="product-img">
                                            <img src="<?php echo e(asset('images/' . $product->image_url)); ?>"
                                                class="card-img-top img-fluid" alt="<?php echo e($product->name); ?>">
                                        </div>
                                    </a>
                                    <div class="card-body text-center">
                                        <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                            class="text-decoration-none text-dark-custom product-name">
                                            <?php echo e($product->name); ?>

                                            <?php if($product->discount_percentage): ?>
                                                <!-- Biểu tượng "Sale" -->
                                                <div
                                                    class="position-absolute top-0 end-0 bg-danger text-white text-center p-2 rounded-start">
                                                    <?php echo e($product->discount_percentage); ?>%
                                                </div>
                                            <?php endif; ?>
                                        </a>
                                        <div class="product-price-wrapper">
                                            <p class="card-text m-0"><?php echo e($product->price_range); ?></p>
                                            <?php if($product->old_price): ?>
                                                <div class="price-sale">
                                                    <del class="product-old-price"><?php echo e(number_format($product->old_price, 0, ',', '.')); ?>

                                                        ₫</del>
                                                </div>
                                            <?php else: ?>
                                                <div class="price-sale empty-sale"></div>
                                            <?php endif; ?>
                                        </div>
                                        <div
                                            class="product-btn d-flex flex-column flex-sm-row justify-content-center align-items-center">
                                            <a href="<?php echo e(route('productsClient.show', $product->id)); ?>"
                                                class="text-decoration-none mb-2 mb-sm-0">
                                                <button class="btn btn-danger me-md-1">
                                                    <i class="fa fa-shopping-cart me-1"></i>
                                                    <span class="small">Giỏ hàng</span>
                                                </button>
                                            </a>

                                            <a href="<?php echo e(route('favorites.add', $product->id)); ?>"
                                                class="text-decoration-none">
                                                <button class="btn btn-secondary">
                                                    <i class="fas fa-heart me-1 ms-md-1"></i>
                                                    <span class="small">Yêu thích</span>
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/client/products.blade.php ENDPATH**/ ?>