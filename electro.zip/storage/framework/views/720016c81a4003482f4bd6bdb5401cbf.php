<?php if(Session::has('error')): ?>
<div id="errorAlert" class="alert alert-danger position-fixed top-0 end-0 mt-3 me-3" style="z-index: 9999;">
    <?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
<div id="successAlert" class="alert alert-success position-fixed top-0 end-0 mt-3 me-3" style="z-index: 9999;">
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>
<script>
    // Tự động đóng thông báo sau 5 giây
    setTimeout(function() {
        var errorAlert = document.getElementById('errorAlert');
        var successAlert = document.getElementById('successAlert');
        if (errorAlert) {
            errorAlert.style.display = 'none';
        }
        if (successAlert) {
            successAlert.style.display = 'none';
        }
    }, 2000);
</script>
<?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/admin/layout/alert.blade.php ENDPATH**/ ?>