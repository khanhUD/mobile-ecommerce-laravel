
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3">
                        <div class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex flex-column flex-md-row align-items-center justify-content-between">
                            <h5 class="text-white text-capitalize ps-3"><?php echo e($title); ?></h5>
                            <a href="<?php echo e(route('attributes.index')); ?>">
                                <button type="button" class="btn btn-primary text-capitalize me-md-4 mb-2 mb-md-0">
                                    Danh sách
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2 mx-3">
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="p-3">
                                    <form id="attributesAddForm" action="<?php echo e(route('attributes.store')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="attribute_name" class="form-label">Tên thuộc tính</label>
                                            <input type="text" class="form-control" id="attribute_name" name="attribute_name">
                                            <?php $__errorArgs = ['attribute_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <a href="<?php echo e(route('attributes.index')); ?>">
                                                <button type="button" class="btn btn-secondary me-2">Đóng</button>
                                            </a>
                                            <button type="submit" class="btn btn-primary">Thêm</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/attributes/add.blade.php ENDPATH**/ ?>