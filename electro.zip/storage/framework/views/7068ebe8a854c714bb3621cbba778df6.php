

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header p-0 position-relative mt-n4 mx-3">
                        <div
                            class="bg-gradient-dark shadow-danger border-radius-lg pt-4 pb-3 d-flex align-items-center justify-content-between">
                            <h5 class="text-white text-capitalize ps-3 mb-0">Danh sách voucher</h5>
                            <a href="<?php echo e(route('vouchers.create')); ?>" class="btn btn-primary text-capitalize me-4">Thêm mới</a>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">STT
                                        </th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Code
                                        </th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Ngày
                                            bắt đầu</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Ngày
                                            kết thúc</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Số
                                            lượng</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Đã
                                            dùng</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Giảm
                                            giá (%)</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Giảm
                                            tối đa</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="ps-4"><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($voucher->code); ?></td>
                                            <td><?php echo e($voucher->start_date); ?></td>
                                            <td><?php echo e($voucher->end_date); ?></td>
                                            <td><?php echo e($voucher->quantity); ?></td>
                                            <td><?php echo e($voucher->used); ?></td>
                                            <td><?php echo e(intval($voucher->discount_percentage)); ?>%</td>
                                            <td><?php echo e(number_format($voucher->max_discount_amount, 0, ',', '.')); ?>đ</td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('vouchers.edit', $voucher->id)); ?>"
                                                    class="btn btn-warning btn-sm">Sửa</a>
                                                <form action="<?php echo e(route('vouchers.destroy', $voucher->id)); ?>" method="POST"
                                                    style="display:inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="mt-3">
                                <?php echo e($vouchers->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\electro_laravel\electro\resources\views/pages/admin/vouchers/index.blade.php ENDPATH**/ ?>