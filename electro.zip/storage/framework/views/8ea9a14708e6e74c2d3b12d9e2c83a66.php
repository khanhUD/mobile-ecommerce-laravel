<!DOCTYPE html>
<html lang="en">

    <?php echo $__env->make('components.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="g-sidenav-show  bg-gray-100">
    <?php echo $__env->make('components.admin.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main-content border-radius-lg ">
        <!-- Navbar -->
        <?php echo $__env->make('components.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Navbar -->
        <!-- content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- <?php echo $__env->make('components.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
        <!--end content -->
    </main>
    <!--   Core JS Files   -->
    <?php echo $__env->make('components.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\khanhvacacmonhoc\Du_an_cv\website_electro_laravel\electro\resources\views/layouts/admin/main.blade.php ENDPATH**/ ?>